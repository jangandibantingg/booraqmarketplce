<div class="modal fade" id="resetpasswordModal" tabindex="-1" role="dialog" aria-labelledby="resetpasswordModal"
     aria-hidden="true">
    <div class="modal-dialog " role="document">

        <div class="modal-content">
            <div class="modal-header">
                <h5 class="text-center ">Reset Password</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <form action="#">
                    <div class="form-group">
                        <label> Masukan Email Anda</label>
                        <input type="email" name="email" placeholder="Masukkan Email Anda" class="form-control">

                    </div>

                    <div class="form-group">
                        <button class="btn btn-secondary btn-block">Ganti Password</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>