<div class="modal fade" id="passwordModal" tabindex="-1" role="dialog" aria-labelledby="modalPassword"
     aria-hidden="true">
    <div class="modal-dialog " role="document">

        <div class="modal-content">
            <div class="modal-header">
                <h5 class="text-center ">Ubah Kata Sandi</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">


                <form action="#">
                    <div class="form-group">
                        <label> Password Lama</label>
                        <input type="text" name="email" placeholder="Masukan Password Lama" class="form-control">
                    </div>
                    <div class="form-group">
                        <label> Password Baru</label>
                        <input type="text" name="lastname" placeholder="Masukkan Kata Sandi Baru" class="form-control">
                    </div>
                    <div class="form-group">
                        <label> Ulangi Kata Sandi</label>
                        <input type="text" name="lastname" placeholder="Ulangi Kata Sandi Baru" class="form-control">
                    </div>
                    <div class="form-group">
                        <button class="btn btn-secondary btn-block">Ganti Password</button>
                    </div>

                </form>
            </div>

        </div>
    </div>
</div>