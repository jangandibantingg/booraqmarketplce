<main class="page-content">
    <div class="banner-area">
        <div class="container">
            <div class="imgbanner imgbanner-2 mt-30">
                <a href="#">
                    <img src="library/assets/images/banner/banner-horizontal.jpg" alt="banner">
                </a>
            </div>
        </div>
    </div>

    <?php include "view/last_produk.php"; ?>


    <?php include 'view/banner.php'; ?>


    <?php include 'view/last_produk.php';; ?>


    <?php
    include_once "library/partials/home_blog.php";
    include_once "library/partials/home_media_islamic.php";

    ?>
</main>
