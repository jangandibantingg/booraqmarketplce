<main class="page-content">
  <div class="container">

      <?php include 'view/last_produk.php';; ?>



  </div>
  </main>
