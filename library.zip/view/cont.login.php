

<main class="page-content">

		<div class="container mtb-30">
				<div class="row justify-content-center">
						<div class="col-md-6 ">
								<div class="card">
										<div class="card-body">
		<h3>Login</h3>
					<form id="loginform" action="signin.html" method="post">
					<div class="form-group">
						<label class="sr-only">Username or Email</label>
						<input type="email" name="email" placeholder="Email" class="form-control">

					</div>
					<div class="form-group m-b-5">
						<label class="sr-only">Password</label>
						<input type="password" name="password" laceholder="Password" class="form-control">
					</div>
					<div class="form-group form-inline m-b-10 ">

						<div class="form-check">
						
						</div>
					</div><div class="form-group">
						<button class="btn btn-primary" id="submit">Login</button>

					</div>
				</form>
			</div>
	</div>
</div>
</div>

</div>


</main>
