<div class="banners-area bg-white">
    <div class="container">
        <div class="row">

            <!-- Single Banner -->
            <div class="col-md-4">
                <div class="imgbanner mt-30">
                    <a href="#">
                        <img src="library/assets/images/banner/banner1.jpg" alt="bannner image">
                    </a>
                </div>
            </div>
            <!--// Single Banner -->

            <!-- Single Banner -->
            <div class="col-md-4">
                <div class="imgbanner mt-30">
                    <a href="#">
                        <img src="library/assets/images/banner/banner2.jpg" alt="bannner image">
                    </a>
                </div>
            </div>
            <!--// Single Banner -->

            <!-- Single Banner -->
            <div class="col-md-4">
                <div class="imgbanner mt-30">
                    <a href="#">
                        <img src="library/assets/images/banner/banner3.jpg" alt="bannner image">
                    </a>
                </div>
            </div>
            <!--// Single Banner -->

        </div>
    </div>
</div>
