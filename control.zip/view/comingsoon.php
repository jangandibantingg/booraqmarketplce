<main class="page-content ptb-30">

     <!-- Contact Us Area -->

     <div class="container text-center">

         <img src="http://dev.booraq.id/library/assets/images/vector/comingsoon.png" alt="" class="w-50">

         <div class="mt-30">
             <p>Halaman ini masih dalam pengembagan, mohon bersabar</p>
             <a class="btn btn-secondary" href="./"><i class="mdi mdi-chevron-left"></i>Kembali</a>
         </div>

     </div>


 </main>
