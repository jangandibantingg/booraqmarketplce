<section id="shop-checkout-completed">
	<div class="container">
		<div class="p-t-10 m-b-20 text-center">
			<div class="text-center">
				<h3>TERIMA KASIH</h3>
				<p>sudah berbelanja di boraq.id
				<hr>
				<p>kami sekaku berusaha agar pesanan anda tiba secepatnya, karenanya pesana  anda mungkin datang secara terpisah dalam waktu yang berbeda</p>
			</div>
	    <a class="btn icon-left" href="beranda.aspx"><span>kembali ke beranda</span></a>
		</div>
	</div>
</section>
