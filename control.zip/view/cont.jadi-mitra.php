<?php $r=mysqli_fetch_array(mysqli_query($con, "select * from article where id_article='2'")) ?>
  <main class="page-content">
<div class="container">
       <div class="row">
           <div class="col-md-6">
               <div class="imgbanner mt-30">
                   <a href="./?page=profile&act=edit-toko&hal=regular">
                       <img src="library/assets/images/banner/mitra_personal.jpg" alt="bannner image">
                   </a>
               </div>
           </div>

           <div class="col-md-6">
               <div class="imgbanner mt-30">
                   <a href="mitra-terdaftar.aspx">
                       <img src="library/assets/images/banner/mitra_terdaftar.jpg" alt="bannner image">
                   </a>
               </div>
           </div>
           <!--// Single Banner -->


       </div>
   </div>

         <!-- Team Area -->
         <div class="pt-30 mb-30">
             <div class="container">
                 <div class="row">
                     <div class="col-12">
                         <div class="section-title">
                             <h3><strong>MITRA FAQ</strong></h3>
                         </div>
                     </div>
                 </div>
                 <div class="row justify-content-center">



                     <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                         <a href="#">
                             <div class="faqbox">
                                 <i class="icon-commerce-process"></i>
                                 <h5>Cara Berjualan</h5>

                             </div>
                         </a>

                     </div>
                     <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                         <a href="#">
                             <div class="faqbox">
                                 <i class="icon-commerce-process"></i>
                                 <h5>Cara Berjualan</h5>

                             </div>
                         </a>

                     </div>

                     <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                         <a href="#">
                             <div class="faqbox">
                                 <i class="icon-commerce-process"></i>
                                 <h5>Cara Berjualan</h5>

                             </div>
                         </a>

                     </div>
                     <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                         <a href="#">
                             <div class="faqbox">
                                 <i class="icon-commerce-process"></i>
                                 <h5>Cara Berjualan</h5>

                             </div>
                         </a>

                     </div>
                     <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                         <a href="#">
                             <div class="faqbox">
                                 <i class="icon-commerce-process"></i>
                                 <h5>Cara Berjualan</h5>

                             </div>
                         </a>

                     </div>
                     <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                         <a href="#">
                             <div class="faqbox">
                                 <i class="icon-commerce-process"></i>
                                 <h5>Cara Berjualan</h5>

                             </div>
                         </a>

                     </div>








                 </div>
             </div>
         </div>
         <!--// Team Area -->

     </main>
