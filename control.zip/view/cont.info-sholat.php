
<section id="page-content">
    <div class="container">


<h1>info sholat</h1>
<center><iframe style="width: 182px; height: 358px; border: 1px solid #ddd;" frameBorder="0" scrolling="no" src="https://www.islamicfinder.org/prayer-widget/">
</iframe></center>
</div>
</section>
