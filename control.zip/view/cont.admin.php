<section id="page-content">
            <div class="container">
                <div class="row">
                    <!-- content -->
                     <?php include 'view/adm.content.php'; ?>
                    <!-- end: content -->

                    <!-- Sidebar-->
                    <div class="sidebar sticky-sidebar col-lg-3">

                            <!--widget newsletter-->
                            <div class="widget  widget-newsletter">

                                <form id="widget-search-form-sidebar" action="" method="get" class="form-inline">
                                    <div class="input-group">
                                        <input type="text" aria-required="true" name="q" class="form-control widget-search-form" placeholder="Search for pages...">
                                         <div class="input-group-append">
                                            <span class="input-group-btn">
                                              <button type="submit" id="widget-widget-search-form-button" class="btn"><i class="fa fa-search"></i></button>
                                              </span>
  										</div> </div>
                                </form>
                            </div>
                            <!--end: widget newsletter-->

                            <!--Tabs with Posts-->
                            <div class="widget clearfix widget-categories">
                              <h4 class="widget-title">MENU</h4>
                              <ul class="list list-arrow-icons">
                                <li> <a title="" href="./?page=admin&hal=tentang-kami"><i class="fa fa-book"></i> TENTANG KAMI </a> </li>
                                <li> <a title="" href="./?page=admin&hal=jadi-mitra"><i class="fa fa-book"></i> JADI MITRA </a> </li>
                                <li> <a title="" href="./?page=admin&hal=article"><i class="fa fa-book"></i> ARTIKEL </a> </li>


                              </ul>
                          </div>
                          <div class="widget clearfix widget-categories">
                            <h4 class="widget-title">Kelola Member dan toko</h4>
                            <ul class="list list-arrow-icons">
                              <li> <a title="" href="./?page=admin&hal=member"><i class="fa fa-user"></i> DAFTAR MEMBER </a> </li>
                              <li> <a title="" href="./?page=admin&hal=seller-regular"><i class="fa fa-store"></i> DAFTAR SELLER REGULER </a> </li>
                              <li> <a title="" href="./?page=admin&hal=seller-premium"><i class="fa fa-store"></i> DAFTAR SELLER PREMIUN </a> </li>


                            </ul>
                        </div>
                            <!--End: Tabs with Posts-->

                            <!-- Twitter widget -->
                            <div class="widget widget-tweeter" data-username="jadwalsholat" data-limit="2">
                                <h4 class="widget-title">Recent Tweets Jadwal sholat</h4>
                            </div>
                            <!-- end: Twitter widget-->

                            <!--widget tags -->
                            <div class="widget  widget-tags">
                                <h4 class="widget-title">Tags</h4>
                                <div class="tags">
                                    <a href="#">Design</a>
                                    <a href="#">Portfolio</a>
                                    <a href="#">Digital</a>
                                    <a href="#">Branding</a>
                                    <a href="#">HTML</a>
                                    <a href="#">Clean</a>
                                    <a href="#">Peace</a>
                                    <a href="#">Love</a>
                                    <a href="#">CSS3</a>
                                    <a href="#">jQuery</a>
                                </div>
                            </div>
                            <!--end: widget tags -->



                    </div>
                    <!-- end: sidebar-->
                </div>
            </div>
        </section>
