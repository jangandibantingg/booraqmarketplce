<div class="media-islami-area bg-grey ptb-30">
    <div class="container">
        <div class="section-title">
            <h3>MEDIA ISLAMI</h3>
        </div>
        <div class="media-islami-slider slider-navigation-3 ptb-30">

            <a class="media-islami-item text-center" href="comingsoon.aspx">
                <img src="library/assets/images/icons/media_logo.png" alt="">
                <div>Media Islamic</div>
            </a>


            <a class="media-islami-item text-center" href="comingsoon.aspx">
                <img src="library/assets/images/icons/media_logo.png" alt="">
                <div>Media Islamic</div>
            </a>


            <a class="media-islami-item text-center" href="comingsoon.aspx">
                <img src="library/assets/images/icons/media_logo.png" alt="">
                <div>Media Islamic</div>
            </a>


            <a class="media-islami-item text-center" href="comingsoon.aspx">
                <img src="library/assets/images/icons/media_logo.png" alt="">
                <div>Media Islamic</div>
            </a>


            <a class="media-islami-item text-center" href="comingsoon.aspx">
                <img src="library/assets/images/icons/media_logo.png" alt="">
                <div>Media Islamic</div>
            </a>


            <a class="media-islami-item text-center" href="comingsoon.aspx">
                <img src="library/assets/images/icons/media_logo.png" alt="">
                <div>Media Islamic</div>
            </a>


            <a class="media-islami-item text-center" href="comingsoon.aspx">
                <img src="library/assets/images/icons/media_logo.png" alt="">
                <div>Media Islamic</div>
            </a>


            <a class="media-islami-item text-center" href="comingsoon.aspx">
                <img src="library/assets/images/icons/media_logo.png" alt="">
                <div>Media Islamic</div>
            </a>


            <a class="media-islami-item text-center" href="comingsoon.aspx">
                <img src="library/assets/images/icons/media_logo.png" alt="">
                <div>Media Islamic</div>
            </a>


            <a class="media-islami-item text-center" href="comingsoon.aspx">
                <img src="library/assets/images/icons/media_logo.png" alt="">
                <div>Media Islamic</div>
            </a>


        </div>
    </div>
</div>
