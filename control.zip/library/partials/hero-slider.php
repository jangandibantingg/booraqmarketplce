
<div class="herobanner herobanner-2 slider-navigation slider-dots slider-dots-center">

    <a class="herobanner-single">
        <img src="library/assets/images/slider/hero-image-3.jpg" alt="hero image">

        <span class="herobanner-progress"></span>
    </a>

    <a class="herobanner-single">
        <img src="library/assets/images/slider/hero-image-4.jpg" alt="hero image">
    </a>


</div>
