<footer class="footer ">
    <div class="footer-toparea">
        <div class="container">
            <div class="row">

                <div class="col-lg-3">
                    <div class="footer-widget widget-links">
                        <h5 class="footer-widget-title">Jelajahi Booraqs</h5>
                        <ul>
                            <li><a href="#">Tentang Kami</a></li>
                            <li><a href="#">Market Place</a></li>
                            <li><a href="#">Info Sholats</a></li>
                            <li><a href="#">Jadi Mitra</a></li>

                        </ul>
                    </div>
                </div>

                <div class="col-lg-2 col-md-4">
                    <div class="footer-widget widget-links">
                        <h5 class="footer-widget-title">Jasa Pengiriman</h5>
                        <ul>
                            <li><a href="#">JNE</a></li>
                            <li><a href="#">TIKI</a></li>
                            <li><a href="#">J&T</a></li>
                            <li><a href="#">Ninja Express</a></li>

                        </ul>
                    </div>
                </div>

                <div class="col-lg-2 col-md-4">
                    <div class="footer-widget widget-links">
                        <h5 class="footer-widget-title">Pembeli</h5>
                        <ul>
                            <li><a href="#">Cara Belanja</a></li>
                            <li><a href="#">Pembayaran</a></li>
                            <li><a href="#">Pengembalian Produk</a></li>

                        </ul>
                    </div>
                </div>

                <div class="col-lg-2 col-md-4">
                    <div class="footer-widget widget-links">
                        <h5 class="footer-widget-title">Penjual</h5>
                        <ul>
                            <li><a href="#">Cara Jadi Mitra</a></li>
                            <li><a href="#">Penarikan Dana</a></li>
                            <li><a href="#">Pengiriman Product</a></li>

                        </ul>
                    </div>
                </div>

                <div class="col-lg-3 col-md-12">
                    <div class="footer-widget widget-links">
                        <h5 class="footer-widget-title">Bantuan</h5>
                        <ul>
                            <li><a href="#">Syarat Dan Ketentuan</a></li>
                            <li><a href="#">Kebijakan Privasi</a></li>
                            <li><a href="#">Cara Beriklan</a></li>
                            <li><a href="kontak.html">Hubungi Kami</a></li>

                        </ul>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <div class="footer-bottomarea">
        <div class="container">
            <div class="footer-copyright">
                <p class="copyright">Copyright &copy; <a href="#">Booraq</a> . All Rights Reserved</p>
            </div>
        </div>
    </div>


</footer>